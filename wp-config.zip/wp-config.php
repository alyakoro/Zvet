<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе установки.
 * Необязательно использовать веб-интерфейс, можно скопировать файл в "wp-config.php"
 * и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки базы данных
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://ru.wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Параметры базы данных: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define( 'DB_NAME', 'zvet' );

/** Имя пользователя базы данных */
define( 'DB_USER', 'admin' );

/** Пароль к базе данных */
define( 'DB_PASSWORD', '8913448' );

/** Имя сервера базы данных */
define( 'DB_HOST', 'localhost' );

/** Кодировка базы данных для создания таблиц. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Схема сопоставления. Не меняйте, если не уверены. */
define( 'DB_COLLATE', '' );

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу. Можно сгенерировать их с помощью
 * {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}.
 *
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными.
 * Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'Ge|kc<~3RMpN_Fy3R4xri2W+-LYxoG.?:YYXl0XKV.yBgKv.&>m^M8s*VHQ9]3e7' );
define( 'SECURE_AUTH_KEY',  'dEP|H8{)=!xkdVE9)|F@Vo77N(%eq-,BMNnu<8#s S;Tzd|f1e$,2H>[BcQD?O!W' );
define( 'LOGGED_IN_KEY',    'tQdQqOmLlQH,qg=WGl=XoH=V4Ub_7hx06u^2a4{DOD0;EfF%!a*&[6gy<w+X|K+s' );
define( 'NONCE_KEY',        'o]#dIu*_!$HV0g6`H/C<vw9f1KKIzxv#qfVk Pt6WnO$A*VIWN1#B1H0D`[HXTWi' );
define( 'AUTH_SALT',        'A_>2sw|7ZL]`4^M~KH|4C+[8_xHcZ{9_j,aMf|N{dd|)CEboCOE[^v^i]FwY}3[k' );
define( 'SECURE_AUTH_SALT', '[^mdoFh>;=ME]%&}Nc_JItrF:nMjE[@d>xB|22#~F>TQ1w5y/tqECXU6%UN-;_lS' );
define( 'LOGGED_IN_SALT',   'yd_-[az~z#Hq282N &:=b!e[;/7M mB6I<4av`Apl>  $dC-R>@w8MK-[W8-2QK ' );
define( 'NONCE_SALT',       'U8]9R`LS[g1R1UU!>f&!/>ZabJ8c`uT4~UK.U-4|E0`I|oOKmVAS0cCvMwN@t;.l' );

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в документации.
 *
 * @link https://ru.wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Произвольные значения добавляйте между этой строкой и надписью "дальше не редактируем". */



/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Инициализирует переменные WordPress и подключает файлы. */
require_once ABSPATH . 'wp-settings.php';
